def moduleMain():
    print("moduleMain")