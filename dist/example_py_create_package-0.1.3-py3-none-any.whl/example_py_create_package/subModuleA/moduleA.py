def moduleA():
    print("moduleA")