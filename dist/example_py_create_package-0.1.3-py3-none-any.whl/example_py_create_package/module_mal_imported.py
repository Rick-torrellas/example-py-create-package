def module_mal_imported():
    print('module_mal_imported')