def moduleB():
    print("moduleB")

def Funcion():
    print("Function")