from .moduleMain import moduleMain
import module_mal_imported