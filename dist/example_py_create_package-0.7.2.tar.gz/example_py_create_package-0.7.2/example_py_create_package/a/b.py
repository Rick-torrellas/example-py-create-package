def b():
    print("b")

def culo():
    print("culo")