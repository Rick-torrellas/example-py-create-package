def sin_init():
    print("sin init")