def moduleB():
    print("moduleB")