from .moduleMain import moduleMain
from .initVacio import init_vacio
from example_py_create_package.sinInit import sin_init
from .bienImportado.bien_importado import bienImportado
from example_py_create_package.indexRelleno import __index__
from .a import a

bien_importado = {
    "bienImportado": bienImportado
}