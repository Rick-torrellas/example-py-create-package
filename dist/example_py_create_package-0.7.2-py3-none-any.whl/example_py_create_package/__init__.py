from .moduleMain import moduleMain
from .initVacio import init_vacio
from example_py_create_package.sinInit import sin_init
from .bienImportado.bien_importado import bienImportado
from example_py_create_package.indexRelleno import __index__
import example_py_create_package.a 

bien_importado = {
    "bienImportado": bienImportado
}