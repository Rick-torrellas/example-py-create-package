def module_no_imported():
    print("module_no_imported ")