def index_relleno():
    print("index relleno")