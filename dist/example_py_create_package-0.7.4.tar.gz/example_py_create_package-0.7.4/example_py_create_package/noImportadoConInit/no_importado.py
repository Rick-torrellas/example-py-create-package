def no_importado():
    print('no importado')