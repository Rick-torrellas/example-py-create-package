def c():
    print('c')