def init_vacio():
    print("init_vacio")